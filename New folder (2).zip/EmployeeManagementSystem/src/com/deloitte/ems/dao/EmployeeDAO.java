package com.deloitte.ems.dao;


import com.deloitte.ems.model.Employee;



public interface EmployeeDAO {

	public boolean insertEmployee(Employee employee);
	

}
